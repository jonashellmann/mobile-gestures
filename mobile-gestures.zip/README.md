# mobile-gestures
An add-on for Firefox, which adds gestures to the Android version of the browser for an optimized usability.

## Available gestures in version 0.1.0

### Gestures with three fingers

* Swipe down: 	Open an empty new tab
* Swipe up:		Reload the current tab
